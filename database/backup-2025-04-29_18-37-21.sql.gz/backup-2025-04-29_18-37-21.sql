/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.21-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: erp_ecommerce_db
-- ------------------------------------------------------
-- Server version	10.6.21-MariaDB-ubu2004

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actividades`
--

DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades` (
  `id_actividad` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha_actividad` datetime DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `recordatorio` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id_actividad`),
  KEY `fk_actividades_id_usuario` (`id_usuario`),
  KEY `fk_actividades_id_cliente` (`id_cliente`),
  CONSTRAINT `fk_actividades_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_actividades_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actividades`
--

LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencias`
--

DROP TABLE IF EXISTS `asistencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencias` (
  `id_asistencia` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_entrada` datetime DEFAULT NULL,
  `fecha_salida` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asistencia`),
  KEY `fk_asistencias_id_usuario` (`id_usuario`),
  CONSTRAINT `fk_asistencias_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencias`
--

LOCK TABLES `asistencias` WRITE;
/*!40000 ALTER TABLE `asistencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carrito_compras`
--

DROP TABLE IF EXISTS `carrito_compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carrito_compras` (
  `id_carrito` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_producto_proveedor` varchar(100) DEFAULT NULL,
  `clave_api_proveedor` varchar(100) DEFAULT NULL,
  `num_parte_proveedor` varchar(100) DEFAULT NULL,
  `nombre_api` varchar(100) DEFAULT NULL,
  `marca_api` varchar(100) DEFAULT NULL,
  `categoria_api` varchar(100) DEFAULT NULL,
  `datos_extra` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos_extra`)),
  PRIMARY KEY (`id_carrito`),
  KEY `fk_carrito_compras_id_usuario` (`id_usuario`),
  CONSTRAINT `fk_carrito_compras_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrito_compras`
--

LOCK TABLES `carrito_compras` WRITE;
/*!40000 ALTER TABLE `carrito_compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `carrito_compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ciudades`
--

DROP TABLE IF EXISTS `ciudades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ciudades` (
  `id_ciudad` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_ciudad`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudades`
--

LOCK TABLES `ciudades` WRITE;
/*!40000 ALTER TABLE `ciudades` DISABLE KEYS */;
INSERT INTO `ciudades` VALUES (1,'09001','Álvaro Obregón'),(2,'09002','Azcapotzalco'),(3,'09003','Benito Juárez'),(4,'09004','Coyoacán'),(5,'09005','Cuajimalpa de Morelos'),(6,'09006','Cuauhtémoc'),(7,'09007','Gustavo A. Madero'),(8,'09008','Iztacalco'),(9,'09009','Iztapalapa'),(10,'09010','Magdalena Contreras'),(11,'09011','Miguel Hidalgo'),(12,'09012','Milpa Alta'),(13,'09013','Tláhuac'),(14,'09014','Tlalpan'),(15,'09015','Venustiano Carranza'),(16,'09016','Xochimilco'),(17,'15001','Ecatepec de Morelos'),(18,'15002','Naucalpan de Juárez'),(19,'15003','Tlalnepantla de Baz'),(20,'15004','Atizapán de Zaragoza'),(21,'15005','Cuautitlán Izcalli'),(22,'15006','Texcoco'),(23,'15007','Chalco'),(24,'15008','Nezahualcóyotl'),(25,'19001','Monterrey'),(26,'19002','San Pedro Garza García'),(27,'19003','San Nicolás de los Garza'),(28,'19004','Guadalupe'),(29,'19005','Apodaca'),(30,'19006','Santa Catarina'),(31,'14001','Guadalajara'),(32,'14002','Zapopan'),(33,'14003','Tlaquepaque'),(34,'14004','Tonalá'),(35,'14005','Tlajomulco de Zúñiga');
/*!40000 ALTER TABLE `ciudades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido_p` varchar(100) DEFAULT NULL,
  `apellido_m` varchar(100) DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `segmento` varchar(100) DEFAULT NULL,
  `ciclo_venta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `fk_clientes_id_vendedor` (`id_vendedor`),
  CONSTRAINT `fk_clientes_id_vendedor` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (23,'PRUEBA #8','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(24,'PRUEBA #9','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(25,'PRUEBA #10','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(26,'PRUEBA #11','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(27,'PRUEBA #12','','','activo','erp',NULL,'gobierno','tekne store ecommerce','cotizacion'),(28,'PRUEBA #13','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(29,'PRUEBA #14','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(30,'PRUEBA #15','','','activo','erp',3,'gobierno','tekne store ecommerce','cotizacion'),(31,'PRUEBA #16','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(32,'prueba 1','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(33,'prueba 2','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(34,'prueba 3','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(35,'prueba 4','','','activo','erp',3,'privada','macasa cuentas especiales','cotizacion'),(36,'prueba 5','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(37,'prueba 6','','','activo','erp',3,'gobierno','la plaza ecommerce','cotizacion'),(38,'prueba 7','','','activo','erp',3,'gobierno','macasa cuentas especiales','cotizacion'),(39,'prueba 8','','','activo','erp',1,'gobierno','macasa ecommerce','cotizacion'),(40,'PRUEBA 9','','','activo','erp',3,'gobierno','macasa cuentas especiales','cotizacion'),(41,'PRUEBA10','','','activo','erp',2,'privada','macasa cuentas especiales','cotizacion'),(42,'PRUEBA11','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(43,'PRUEBA 12','','','activo','erp',2,'privada','la plaza ecommerce','cotizacion'),(44,'PRUEBA13','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(45,'PRUEBA14','','','activo','erp',NULL,'gobierno','macasa cuentas especiales','cotizacion'),(46,'PRUEBA15','','','activo','erp',NULL,'privada','tekne store ecommerce','cotizacion'),(47,'PRUEBA16','','','activo','erp',1,'privada','macasa cuentas especiales','cotizacion'),(48,'PRUEBA17','','','activo','erp',NULL,'privada','macasa cuentas especiales','cotizacion'),(49,'PRUEBA18','','','activo','erp',3,'privada','macasa cuentas especiales','cotizacion'),(50,'PRUEBA18','','','activo','erp',3,'privada','macasa cuentas especiales','cotizacion');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) DEFAULT NULL,
  `id_comprador` int(11) DEFAULT NULL,
  `consecutivo_compra` varchar(100) DEFAULT NULL,
  `fecha_compra` datetime DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `fk_compras_id_proveedor` (`id_proveedor`),
  KEY `fk_compras_id_comprador` (`id_comprador`),
  CONSTRAINT `fk_compras_id_comprador` FOREIGN KEY (`id_comprador`) REFERENCES `usuarios` (`id_usuario`),
  CONSTRAINT `fk_compras_id_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras_partidas`
--

DROP TABLE IF EXISTS `compras_partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras_partidas` (
  `id_compras_partidas` int(11) NOT NULL AUTO_INCREMENT,
  `id_compra` int(11) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `cantidad_recibida` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_compras_partidas`),
  KEY `fk_compras_partidas_id_compra` (`id_compra`),
  CONSTRAINT `fk_compras_partidas_id_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras_partidas`
--

LOCK TABLES `compras_partidas` WRITE;
/*!40000 ALTER TABLE `compras_partidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras_partidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactos`
--

DROP TABLE IF EXISTS `contactos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactos` (
  `id_contacto` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido_p` varchar(100) DEFAULT NULL,
  `apellido_m` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `puesto` varchar(100) DEFAULT NULL,
  `telefono1` varchar(100) DEFAULT NULL,
  `ext1` varchar(10) DEFAULT NULL,
  `telefono2` varchar(100) DEFAULT NULL,
  `ext2` varchar(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_contacto`),
  KEY `fk_contactos_id_cliente` (`id_cliente`),
  CONSTRAINT `fk_contactos_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactos`
--

LOCK TABLES `contactos` WRITE;
/*!40000 ALTER TABLE `contactos` DISABLE KEYS */;
INSERT INTO `contactos` VALUES (1,33,'contacto 2',NULL,NULL,'correo2@correo.com','SISTEMAS',NULL,NULL,'9876543210','987','2025-04-28 18:42:24','2025-04-28 18:42:24'),(2,34,'contacto 3',NULL,NULL,'correo3@correo.com','CONTABILIDAD',NULL,NULL,'9632587410','456','2025-04-28 18:53:32','2025-04-28 18:53:32'),(3,35,'contacto 4',NULL,NULL,'correo4@correo.com','ADMINISTRACION',NULL,NULL,'9632587410','159','2025-04-28 19:09:33','2025-04-28 19:09:33'),(4,36,'contacto 5',NULL,NULL,'correo@correo.com','MARKETING',NULL,NULL,'0369874125','159','2025-04-28 19:17:26','2025-04-28 19:17:26'),(5,37,'contacto 6','apellido 6','apellido 6','correo6@correos.com','COMPRAS',NULL,NULL,'0124357689','951','2025-04-28 19:20:06','2025-04-28 19:20:06'),(6,38,'contacto 7','apellido 7','apellido 7','correo7@correo.com','AUXILIAR COMPRAS','0123456789','123','9876543210','789','2025-04-28 19:23:30','2025-04-28 19:23:30'),(7,39,'contacto 8','apellido 8','apellido 8','correo8@correo.com','VENTAS8','5555555555','555','1234567890','156','2025-04-29 17:12:03','2025-04-29 17:12:03'),(8,40,'contacto 9','apellido 9','apellido 9','correo9@correo.com','VENTAS9','123456790','123','1234657890','123','2025-04-29 17:13:20','2025-04-29 17:13:20'),(9,41,'contacto10','apellido10','apellido10','correo10@correo.com','VENTAS10','1324567890','123','1234657890','132','2025-04-29 17:14:27','2025-04-29 17:14:27'),(10,42,'PRUEBA11','PRUEBA11','PRUEBA11','prueba11@correo.com','PRUEBA11','1234567980','132','1324567890','123','2025-04-29 17:15:43','2025-04-29 17:15:43'),(11,43,'PRUEBA 12','PRUEBA 12','PRUEBA 12','PRUEBA12@correo.com','PRUEBA 12','1234657890','132','1234657890','132','2025-04-29 17:16:25','2025-04-29 17:16:25'),(12,44,'PRUEBA13','PRUEBA13','PRUEBA13','PRUEBA13@PRUEBA13.COM','PRUEBA13PRUEBA13','1234567890','13','1324567890','123','2025-04-29 17:17:01','2025-04-29 17:17:01'),(13,45,'PRUEBA14','PRUEBA14','PRUEBA14','PRUEBA14@PRUEBA14.COM','PRUEBA14','2316548970','126','1324657980','156','2025-04-29 17:20:49','2025-04-29 17:20:49'),(14,46,'PRUEBA15','PRUEBA15','PRUEBA15','PRUEBA15@correo.com','PRUEBA15','1324567890','132','0132465789','2','2025-04-29 17:21:42','2025-04-29 17:21:42'),(15,47,'PRUEBA16','PRUEBA16','PRUEBA16','PRUEBA16@correo.com','PRUEBA16','0132465789','123','1234567890','147','2025-04-29 17:22:30','2025-04-29 17:22:30'),(16,48,'PRUEBA17','PRUEBA17','PRUEBA17','PRUEBA17@CORREO.COM','PRUEBA17','1234567890','13','1234657890','123','2025-04-29 18:45:36','2025-04-29 18:45:36'),(17,49,'PRUEBA18','PRUEBA18','PRUEBA18','PRUEBA18@CORREO.COM','PRUEBA18','1234567890','123','1234567890','233','2025-04-29 21:49:13','2025-04-29 21:49:13'),(18,50,'PRUEBA18','PRUEBA18','PRUEBA18','PRUEBA18@CORREO.COM','PRUEBA18','1234567890','123','1234567890','233','2025-04-29 21:50:34','2025-04-29 21:50:34');
/*!40000 ALTER TABLE `contactos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cotizaciones`
--

DROP TABLE IF EXISTS `cotizaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cotizaciones` (
  `id_cotizacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_razon_social` int(11) DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `vencimiento` datetime DEFAULT NULL,
  `id_direccion_entrega` int(11) DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  `id_divisa` int(11) DEFAULT NULL,
  `num_consecutivo` varchar(100) DEFAULT NULL,
  `orden_de_venta` varchar(100) DEFAULT NULL,
  `score_final` decimal(10,2) DEFAULT NULL,
  `notas_entrega` text DEFAULT NULL,
  `notas_facturacion` text DEFAULT NULL,
  `id_termino_pago` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cotizacion`),
  KEY `fk_cotizaciones_id_cliente` (`id_cliente`),
  KEY `fk_cotizaciones_id_razon_social` (`id_razon_social`),
  KEY `fk_cotizaciones_id_direccion_entrega` (`id_direccion_entrega`),
  KEY `fk_cotizaciones_id_vendedor` (`id_vendedor`),
  KEY `fk_cotizaciones_id_divisa` (`id_divisa`),
  CONSTRAINT `fk_cotizaciones_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_cotizaciones_id_direccion_entrega` FOREIGN KEY (`id_direccion_entrega`) REFERENCES `direcciones` (`id_direccion`),
  CONSTRAINT `fk_cotizaciones_id_divisa` FOREIGN KEY (`id_divisa`) REFERENCES `divisas` (`id_divisa`),
  CONSTRAINT `fk_cotizaciones_id_razon_social` FOREIGN KEY (`id_razon_social`) REFERENCES `razones_sociales` (`id_razon_social`),
  CONSTRAINT `fk_cotizaciones_id_vendedor` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cotizaciones`
--

LOCK TABLES `cotizaciones` WRITE;
/*!40000 ALTER TABLE `cotizaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `cotizaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cotizaciones_partidas`
--

DROP TABLE IF EXISTS `cotizaciones_partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cotizaciones_partidas` (
  `id_cotizacion_partida` int(11) NOT NULL AUTO_INCREMENT,
  `id_cotizacion` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `score` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_cotizacion_partida`),
  KEY `fk_cotizaciones_partidas_id_cotizacion` (`id_cotizacion`),
  KEY `fk_cotizaciones_partidas_id_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_cotizaciones_partidas_id_cotizacion` FOREIGN KEY (`id_cotizacion`) REFERENCES `cotizaciones` (`id_cotizacion`),
  CONSTRAINT `fk_cotizaciones_partidas_id_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cotizaciones_partidas`
--

LOCK TABLES `cotizaciones_partidas` WRITE;
/*!40000 ALTER TABLE `cotizaciones_partidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `cotizaciones_partidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `direcciones`
--

DROP TABLE IF EXISTS `direcciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `direcciones` (
  `id_direccion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `calle` varchar(100) DEFAULT NULL,
  `num_ext` varchar(20) DEFAULT NULL,
  `num_int` varchar(20) DEFAULT NULL,
  `colonia` varchar(100) DEFAULT NULL,
  `id_ciudad` int(11) DEFAULT NULL,
  `id_estado` int(11) DEFAULT NULL,
  `id_pais` int(11) DEFAULT NULL,
  `cp` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_direccion`),
  KEY `fk_direcciones_id_cliente` (`id_cliente`),
  KEY `fk_direcciones_id_ciudad` (`id_ciudad`),
  KEY `fk_direcciones_id_estado` (`id_estado`),
  KEY `fk_direcciones_id_pais` (`id_pais`),
  CONSTRAINT `fk_direcciones_id_ciudad` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudades` (`id_ciudad`),
  CONSTRAINT `fk_direcciones_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_direcciones_id_estado` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`),
  CONSTRAINT `fk_direcciones_id_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id_pais`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direcciones`
--

LOCK TABLES `direcciones` WRITE;
/*!40000 ALTER TABLE `direcciones` DISABLE KEYS */;
INSERT INTO `direcciones` VALUES (1,'PRUEBA18PRUEBA18PRUEBA18','entrega',50,'PRUEBA18PRUEBA18','1','1','PRUEBA18PRUEBA18',NULL,NULL,NULL,'01234');
/*!40000 ALTER TABLE `direcciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `divisas`
--

DROP TABLE IF EXISTS `divisas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `divisas` (
  `id_divisa` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `nomenclatura` varchar(10) DEFAULT NULL,
  `tipo_cambio` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_divisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `divisas`
--

LOCK TABLES `divisas` WRITE;
/*!40000 ALTER TABLE `divisas` DISABLE KEYS */;
/*!40000 ALTER TABLE `divisas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `estados` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'AG','Aguascalientes'),(2,'BC','Baja California'),(3,'BS','Baja California Sur'),(4,'CM','Campeche'),(5,'CS','Chiapas'),(6,'CH','Chihuahua'),(7,'DF','Ciudad de México'),(8,'CO','Coahuila'),(9,'CL','Colima'),(10,'DG','Durango'),(11,'EM','Estado de México'),(12,'GT','Guanajuato'),(13,'GR','Guerrero'),(14,'HG','Hidalgo'),(15,'JA','Jalisco'),(16,'MI','Michoacán'),(17,'MO','Morelos'),(18,'NA','Nayarit'),(19,'NL','Nuevo León'),(20,'OA','Oaxaca'),(21,'PU','Puebla'),(22,'QE','Querétaro'),(23,'QR','Quintana Roo'),(24,'SL','San Luis Potosí'),(25,'SI','Sinaloa'),(26,'SO','Sonora'),(27,'TB','Tabasco'),(28,'TM','Tamaulipas'),(29,'TL','Tlaxcala'),(30,'VE','Veracruz'),(31,'YU','Yucatán'),(32,'ZA','Zacatecas');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forma_pagos`
--

DROP TABLE IF EXISTS `forma_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `forma_pagos` (
  `id_forma_pago` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_forma_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forma_pagos`
--

LOCK TABLES `forma_pagos` WRITE;
/*!40000 ALTER TABLE `forma_pagos` DISABLE KEYS */;
INSERT INTO `forma_pagos` VALUES (1,'01','Efectivo'),(2,'02','Cheque nominativo'),(3,'03','Transferencia electrónica de fondos'),(4,'04','Tarjeta de crédito'),(5,'05','Monedero electrónico'),(6,'06','Dinero electrónico'),(7,'08','Vales de despensa'),(8,'12','Dación en pago'),(9,'13','Pago por subrogación'),(10,'14','Pago por consignación'),(11,'15','Condonación'),(12,'17','Compensación'),(13,'23','Novación'),(14,'24','Confusión'),(15,'25','Remisión de deuda'),(16,'26','Prescripción o caducidad'),(17,'27','A satisfacción del acreedor'),(18,'28','Tarjeta de débito'),(19,'29','Tarjeta de servicios'),(20,'30','Aplicación de anticipos'),(21,'99','Por definir'),(22,'01','Efectivo'),(23,'02','Cheque nominativo'),(24,'03','Transferencia electrónica de fondos'),(25,'04','Tarjeta de crédito'),(26,'05','Monedero electrónico'),(27,'06','Dinero electrónico'),(28,'08','Vales de despensa'),(29,'12','Dación en pago'),(30,'13','Pago por subrogación'),(31,'14','Pago por consignación'),(32,'15','Condonación'),(33,'17','Compensación'),(34,'23','Novación'),(35,'24','Confusión'),(36,'25','Remisión de deuda'),(37,'26','Prescripción o caducidad'),(38,'27','A satisfacción del acreedor'),(39,'28','Tarjeta de débito'),(40,'29','Tarjeta de servicios'),(41,'30','Aplicación de anticipos'),(42,'99','Por definir');
/*!40000 ALTER TABLE `forma_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metas_ventas`
--

DROP TABLE IF EXISTS `metas_ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metas_ventas` (
  `id_meta_venta` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `mes_aplicacion` datetime DEFAULT NULL,
  `cuota_facturacion` decimal(10,2) DEFAULT NULL,
  `cuota_marginal` decimal(10,2) DEFAULT NULL,
  `cuota_cotizaciones` decimal(10,2) DEFAULT NULL,
  `cuota_llamadas` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_meta_venta`),
  KEY `fk_metas_ventas_id_usuario` (`id_usuario`),
  CONSTRAINT `fk_metas_ventas_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metas_ventas`
--

LOCK TABLES `metas_ventas` WRITE;
/*!40000 ALTER TABLE `metas_ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `metas_ventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodo_pagos`
--

DROP TABLE IF EXISTS `metodo_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metodo_pagos` (
  `id_metodo_pago` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_metodo_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodo_pagos`
--

LOCK TABLES `metodo_pagos` WRITE;
/*!40000 ALTER TABLE `metodo_pagos` DISABLE KEYS */;
INSERT INTO `metodo_pagos` VALUES (1,'PUE','Pago en Una sola Exhibición'),(2,'PPD','Pago en Parcialidades o Diferido'),(3,'99','por definir'),(4,'PUE','Pago en una sola exhibición'),(5,'PPD','Pago en parcialidades o diferido'),(6,'POR_DEFINIR','Por definir');
/*!40000 ALTER TABLE `metodo_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificaciones` (
  `id_notificacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario_origen` int(11) DEFAULT NULL,
  `id_usuario_destino` int(11) DEFAULT NULL,
  `mensaje` text DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  `fecha_leido` datetime DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `id_referencia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_notificacion`),
  KEY `fk_notificaciones_id_usuario_origen` (`id_usuario_origen`),
  KEY `fk_notificaciones_id_usuario_destino` (`id_usuario_destino`),
  CONSTRAINT `fk_notificaciones_id_usuario_destino` FOREIGN KEY (`id_usuario_destino`) REFERENCES `usuarios` (`id_usuario`),
  CONSTRAINT `fk_notificaciones_id_usuario_origen` FOREIGN KEY (`id_usuario_origen`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `fecha_pago` datetime DEFAULT NULL,
  `id_metodo_pago` int(11) DEFAULT NULL,
  `id_forma_pago` int(11) DEFAULT NULL,
  `id_divisa` int(11) DEFAULT NULL,
  `tipo_cambio` decimal(10,2) DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `es_anticipo` tinyint(1) DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  PRIMARY KEY (`id_pago`),
  KEY `fk_pagos_id_cliente` (`id_cliente`),
  KEY `fk_pagos_id_metodo_pago` (`id_metodo_pago`),
  KEY `fk_pagos_id_forma_pago` (`id_forma_pago`),
  KEY `fk_pagos_id_divisa` (`id_divisa`),
  CONSTRAINT `fk_pagos_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_pagos_id_divisa` FOREIGN KEY (`id_divisa`) REFERENCES `divisas` (`id_divisa`),
  CONSTRAINT `fk_pagos_id_forma_pago` FOREIGN KEY (`id_forma_pago`) REFERENCES `forma_pagos` (`id_forma_pago`),
  CONSTRAINT `fk_pagos_id_metodo_pago` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodo_pagos` (`id_metodo_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises` (
  `id_pais` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_pais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises`
--

LOCK TABLES `paises` WRITE;
/*!40000 ALTER TABLE `paises` DISABLE KEYS */;
/*!40000 ALTER TABLE `paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_cotizacion` int(11) DEFAULT NULL,
  `consecutivo_pedido` varchar(100) DEFAULT NULL,
  `fecha_pedido` datetime DEFAULT NULL,
  `fecha_pdf` datetime DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `id_razon_social` int(11) DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT NULL,
  `id_direccion_entrega` int(11) DEFAULT NULL,
  `id_divisa` int(11) DEFAULT NULL,
  `orden_en_venta` varchar(100) DEFAULT NULL,
  `factura_pdf` varchar(100) DEFAULT NULL,
  `factura_xml` varchar(100) DEFAULT NULL,
  `score_final` decimal(10,2) DEFAULT NULL,
  `notas_entrega` text DEFAULT NULL,
  `notas_facturacion` text DEFAULT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `fk_pedidos_id_cotizacion` (`id_cotizacion`),
  KEY `fk_pedidos_id_cliente` (`id_cliente`),
  KEY `fk_pedidos_id_razon_social` (`id_razon_social`),
  KEY `fk_pedidos_id_vendedor` (`id_vendedor`),
  KEY `fk_pedidos_id_direccion_entrega` (`id_direccion_entrega`),
  KEY `fk_pedidos_id_divisa` (`id_divisa`),
  CONSTRAINT `fk_pedidos_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_pedidos_id_cotizacion` FOREIGN KEY (`id_cotizacion`) REFERENCES `cotizaciones` (`id_cotizacion`),
  CONSTRAINT `fk_pedidos_id_direccion_entrega` FOREIGN KEY (`id_direccion_entrega`) REFERENCES `direcciones` (`id_direccion`),
  CONSTRAINT `fk_pedidos_id_divisa` FOREIGN KEY (`id_divisa`) REFERENCES `divisas` (`id_divisa`),
  CONSTRAINT `fk_pedidos_id_razon_social` FOREIGN KEY (`id_razon_social`) REFERENCES `razones_sociales` (`id_razon_social`),
  CONSTRAINT `fk_pedidos_id_vendedor` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_partidas`
--

DROP TABLE IF EXISTS `pedidos_partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos_partidas` (
  `id_pedido_partida` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `estatus` varchar(100) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `score` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_pedido_partida`),
  KEY `fk_pedidos_partidas_id_pedido` (`id_pedido`),
  KEY `fk_pedidos_partidas_id_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_pedidos_partidas_id_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  CONSTRAINT `fk_pedidos_partidas_id_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_partidas`
--

LOCK TABLES `pedidos_partidas` WRITE;
/*!40000 ALTER TABLE `pedidos_partidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos_partidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `id_direccion` int(11) DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `ext` varchar(10) DEFAULT NULL,
  `celular` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`),
  KEY `fk_proveedores_id_direccion` (`id_direccion`),
  CONSTRAINT `fk_proveedores_id_direccion` FOREIGN KEY (`id_direccion`) REFERENCES `direcciones` (`id_direccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `razones_sociales`
--

DROP TABLE IF EXISTS `razones_sociales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `razones_sociales` (
  `id_razon_social` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `RFC` varchar(13) DEFAULT NULL,
  `id_metodo_pago` int(11) DEFAULT NULL,
  `id_forma_pago` int(11) DEFAULT NULL,
  `id_regimen_fiscal` int(11) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `limite_credito` decimal(10,2) DEFAULT NULL,
  `dias_credito` int(11) DEFAULT NULL,
  `id_direccion_facturacion` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_razon_social`),
  KEY `fk_razones_sociales_id_cliente` (`id_cliente`),
  KEY `fk_razones_sociales_id_metodo_pago` (`id_metodo_pago`),
  KEY `fk_razones_sociales_id_forma_pago` (`id_forma_pago`),
  KEY `fk_razones_sociales_id_regimen_fiscal` (`id_regimen_fiscal`),
  KEY `fk_razones_sociales_id_direccion_facturacion` (`id_direccion_facturacion`),
  CONSTRAINT `fk_razones_sociales_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `fk_razones_sociales_id_direccion_facturacion` FOREIGN KEY (`id_direccion_facturacion`) REFERENCES `direcciones` (`id_direccion`),
  CONSTRAINT `fk_razones_sociales_id_forma_pago` FOREIGN KEY (`id_forma_pago`) REFERENCES `forma_pagos` (`id_forma_pago`),
  CONSTRAINT `fk_razones_sociales_id_metodo_pago` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodo_pagos` (`id_metodo_pago`),
  CONSTRAINT `fk_razones_sociales_id_regimen_fiscal` FOREIGN KEY (`id_regimen_fiscal`) REFERENCES `regimen_fiscales` (`id_regimen_fiscal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `razones_sociales`
--

LOCK TABLES `razones_sociales` WRITE;
/*!40000 ALTER TABLE `razones_sociales` DISABLE KEYS */;
/*!40000 ALTER TABLE `razones_sociales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regimen_fiscales`
--

DROP TABLE IF EXISTS `regimen_fiscales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `regimen_fiscales` (
  `id_regimen_fiscal` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo_persona` enum('Física','Moral','Ambas') DEFAULT 'Física',
  PRIMARY KEY (`id_regimen_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regimen_fiscales`
--

LOCK TABLES `regimen_fiscales` WRITE;
/*!40000 ALTER TABLE `regimen_fiscales` DISABLE KEYS */;
INSERT INTO `regimen_fiscales` VALUES (1,'601','General de Ley Personas Morales','Moral'),(2,'603','Personas Morales con Fines no Lucrativos','Moral'),(3,'607','Régimen de Enajenación o Adquisición de Bienes','Moral'),(4,'610','Residentes en el Extranjero sin Establecimiento Permanente en México','Moral'),(5,'622','Actividades Agrícolas, Ganaderas, Silvícolas y Pesqueras','Moral'),(6,'623','Opcional para Grupos de Sociedades','Moral'),(7,'624','Coordinados','Moral'),(8,'626','Régimen Simplificado de Confianza','Moral'),(9,'628','Hidrocarburos','Moral'),(10,'605','Sueldos y Salarios e Ingresos Asimilados a Salarios','Física'),(11,'606','Arrendamiento','Física'),(12,'608','Demás ingresos','Física'),(13,'611','Ingresos por Dividendos (socios y accionistas)','Física'),(14,'612','Personas Físicas con Actividades Empresariales y Profesionales','Física'),(15,'614','Ingresos por intereses','Física'),(16,'615','Régimen de los ingresos por obtención de premios','Física'),(17,'616','Sin obligaciones fiscales','Física'),(18,'621','Incorporación Fiscal','Física'),(19,'625','Régimen de las Actividades Empresariales con ingresos a través de Plataformas Tecnológicas','Física'),(20,'629','De los Regímenes Fiscales Preferentes y de las Empresas Multinacionales','Física'),(21,'630','Enajenación de acciones en bolsa de valores','Física');
/*!40000 ALTER TABLE `regimen_fiscales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('f43vY0roghQSv73TM5sr1I4AiDcNuN3EegOnrmFs',1,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiVER4WlRTV1hUQmxqR25OdThsZFM3SjVyNUg3aFdqSUNTbW01MWlWQiI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQzOiJodHRwOi8vbG9jYWxob3N0L2NsaWVudGVzL2NyZWF0ZT90aXBvPW1vcmFsIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9',1745969114),('YuNN6FGqxUiaeEL4upei2ZyfQEf1s29p6MMXZHO4',3,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZFpWbGlmU1JuMzlKNEpCN0ZZZUtCcjlvYzBzb1NheG8zTHBTUTFrbCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjUxOiJodHRwOi8vc2lzdGVtYXMtMDEubG9jYWwvY2xpZW50ZXMvY3JlYXRlP3RpcG89bW9yYWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1745968139);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uso_cfdis`
--

DROP TABLE IF EXISTS `uso_cfdis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `uso_cfdis` (
  `id_uso_cfdi` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(50) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_uso_cfdi`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uso_cfdis`
--

LOCK TABLES `uso_cfdis` WRITE;
/*!40000 ALTER TABLE `uso_cfdis` DISABLE KEYS */;
INSERT INTO `uso_cfdis` VALUES (1,'G01','Adquisición de mercancías'),(2,'G02','Devoluciones, descuentos o bonificaciones'),(3,'G03','Gastos en general'),(4,'I01','Construcciones'),(5,'I02','Mobiliario y equipo de oficina por inversiones'),(6,'I03','Equipo de transporte'),(7,'I04','Equipo de cómputo y accesorios'),(8,'I05','Dados, troqueles, moldes, matrices y herramental'),(9,'I06','Comunicaciones telefónicas'),(10,'I07','Comunicaciones satelitales'),(11,'I08','Otra maquinaria y equipo'),(12,'D01','Honorarios médicos, dentales y gastos hospitalarios'),(13,'D02','Gastos médicos por incapacidad o discapacidad'),(14,'D03','Gastos funerales'),(15,'D04','Donativos'),(16,'D05','Intereses reales efectivamente pagados por créditos hipotecarios (casa habitación)'),(17,'D06','Aportaciones voluntarias al SAR'),(18,'D07','Primas por seguros de gastos médicos'),(19,'D08','Gastos de transportación escolar obligatorio'),(20,'D09','Depósitos en cuentas para el ahorro, primas que tengan como base planes de pensiones'),(21,'D10','Pagos por servicios educativos (colegiaturas)'),(22,'S01','Sin efectos fiscales'),(23,'CP01','Pagos'),(24,'CN01','Nómina');
/*!40000 ALTER TABLE `uso_cfdis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `cargo` varchar(100) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `estatus` varchar(50) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `es_admin` tinyint(1) DEFAULT 0,
  `fecha_alta` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `fk_usuarios_id_cliente` (`id_cliente`),
  CONSTRAINT `fk_usuarios_id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'sistemas','sistemas@macasahs.com.mx','$2y$12$9EIEHsxJ4Ys1u5SCfww4CepNZfMcUWtgiETV5/tTdYMXN5PMmZGIq','Sistemas','ERP','Activo',NULL,1,NULL),(2,'prueba','prueba@prueba.com','$2y$12$AE.IS5l3d.VU9Un.P6gjHuvexVE4dWgASACXhbpC656nM/3RQbQHe','Ejecutivo','ERP','Activo',NULL,0,'2025-04-22 15:48:18'),(3,'mcarreon','mcarreon@macasahs.com.mx','$2y$12$mBu5m9DXuShfD3PcCVYmL.uNOMqp2PFd8/bxjz8KWVrDKLyuCIzSu','Direccion','ERP','Activo',NULL,1,'2025-04-23 11:08:14');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-30  0:37:22
